"""
A=[]
for i in range(3):
  for j in range(4):
    A[i].append(j)

print(A)
  for j in range(4):
    A[i].append(j)

print(A)
"""

